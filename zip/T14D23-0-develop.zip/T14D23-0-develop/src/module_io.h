#ifndef MODULE_IO_H
#define MODULE_IO_H

#include <stdio.h>

int saveScan(int *input);
char *charInput();
void str_output(char *str);
char *s21_strcat(char *str1, char *str2);
int scan_date(int *day, int *month, int *year);

#endif
