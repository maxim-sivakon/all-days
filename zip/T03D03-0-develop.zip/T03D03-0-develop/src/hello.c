 #include <stdio.h>

 int main(void){
     printf("Hello, AI!");
     return 0;
 }
