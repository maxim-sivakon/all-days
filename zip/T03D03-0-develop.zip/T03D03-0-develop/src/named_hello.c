 #include <stdio.h>

 int main(void){

     int userName;
     scanf("%d", &userName);
     printf("Hello,%d", userName);
     return 0;
 }
