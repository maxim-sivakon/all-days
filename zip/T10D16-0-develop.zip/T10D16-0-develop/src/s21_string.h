#ifndef S21_STRING_H
#define S21_STRING_H

int s21_string(char str_length[]);
void s21_checkString(char str_length[], int length);

#endif
