#ifndef SRC_LOG_LEVELS_H_
#define SRC_LOG_LEVELS_H_

enum log_level { debug = 0, trace, info, warning, error };

#endif  // SRC_LOG_LEVELS_H_
